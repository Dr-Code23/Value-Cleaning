<?php

return [
    'name' => 'Chat'
];
