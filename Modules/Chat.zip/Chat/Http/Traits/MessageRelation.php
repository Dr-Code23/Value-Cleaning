<?php


namespace Modules\Chat\Http;


class MessageRelation
{

}
